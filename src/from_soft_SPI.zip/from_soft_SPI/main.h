/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#define __IO volatile


#include "Soft_SPI.h"
//#include "stm32f4xx_hal.h"
//#include "stm32f407xx.h"
//#include "stm32f4xx_hal_uart.h"
//#include "stm32f4xx_hal_rcc.h"
//#include "stm32f4xx_hal_flash.h"

#include "kprint.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

extern UART_HandleTypeDef huart1;

void Error_Handler(void);

void NVIC_SystemReset(void);

extern void k_delay(const uint32_t ms);
extern uint32_t k_ticks(void);

/*** Application-Specific Configuration ***************************************/
/* File name of application located on SD card */
#define CONF_FILENAME "FIRMWARE.bin"
#define FILE_EXT_CHANGE "CUR"
/* For development/debugging: print messages to ST-LINK VCP */
#define USE_VCP 1
/******************************************************************************/

/* Hardware Defines ----------------------------------------------------------*/
 
#define Detect_SDIO_GPIO_Pin GPIO_PIN_11 
#define Detect_SDIO_GPIO_Port GPIOB
#define SD_MISO_Pin GPIO_PIN_6
#define SD_MISO_GPIO_Port GPIOA
#define SDSS_Pin GPIO_PIN_4
#define SDSS_GPIO_Port GPIOA
#define SD_SCK_Pin GPIO_PIN_5
#define SD_SCK_GPIO_Port GPIOA
#define SD_MOSI_Pin GPIO_PIN_5
#define SD_MOSI_GPIO_Port GPIOB

//#define WORK_LED_Pin GPIO_PIN_2
//#define WORK_LED_GPIO_Port GPIOB

/* LD2 */
#define LED_G1_Port GPIOA
#define LED_G1_Pin  GPIO_PIN_6

/* LD3 */
#define LED_G2_Port GPIOA
#define LED_G2_Pin  GPIO_PIN_7

/* Enumerations --------------------------------------------------------------*/
/* Error codes */
enum eApplicationErrorCodes
{
    ERR_OK = 0,
    ERR_WRP_ACTIVE,
    ERR_SD_INIT,
    ERR_SD_MOUNT,
    ERR_SD_FILE,
    ERR_APP_LARGE,
    ERR_FLASH,
    ERR_VERIFY,
    ERR_OBP,
};

/* Hardware Macros -----------------------------------------------------------*/


/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

// Soft SPI

void spiBegin(void);
void spiInit(uint8_t spiRate);
uint8_t SOFT_SPI_STM32_SpiTransfer_Mode_3(uint8_t b);




enum Spi_Speed
{
  SPI_FULL_SPEED = 0,
  SPI_HALF_SPEED,
  SPI_QUARTER_SPEED,
  SPI_EIGHTH_SPEED,
  SPI_SPEED_5,
  SPI_SPEED_6,
};


//#define FCLK_SLOW() { spiInit(SPI_QUARTER_SPEED); }	/* Set SCLK = slow, approx 280 KBits/s*/
//#define FCLK_FAST() { spiInit(SPI_FULL_SPEED); }	/* Set SCLK = fast, approx 1 MBits/s */
#define FCLK_SLOW() {}  // STM32F103 is so slow can only run at the slow speed
#define FCLK_FAST() {}	// STM32F103 is so slow can only run at the slow speed

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler_Boot(void);

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
