/*
 * Author: Aurelio Colosimo, 2016
 *
 * This file is part of kim-os project: https://github.com/colosimo/kim-os
 * According to kim-os license, you can do whatever you want with it,
 * as long as you retain this notice.
 */

#ifndef _INTDEFS_H_
#define _INTDEFS_H_

#include <stdint.h>
#include <stddef.h>

#define i32 int32_t
#define u32 uint32_t
#define i16 int16_t
#define u16 uint16_t
#define i8 int8_t
#define u8 uint8_t

#define uint unsigned int

#endif /* _INTDEFS_H_ */
